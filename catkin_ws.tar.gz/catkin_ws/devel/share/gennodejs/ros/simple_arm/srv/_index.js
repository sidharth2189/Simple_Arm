
"use strict";

let GoToPosition = require('./GoToPosition.js')

module.exports = {
  GoToPosition: GoToPosition,
};
